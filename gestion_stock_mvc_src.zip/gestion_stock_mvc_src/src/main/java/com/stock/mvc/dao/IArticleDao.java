package com.stock.mvc.dao;

import com.stock.mvc.entites.Article;

public interface IArticleDao extends IGenericDao<Article> {

}
