package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.ICommandeFournisseurDao;
import com.stock.mvc.entites.CommandeFournisseur;

public class CommandeFournisseurDaoImpl extends GenericDaoImpl<CommandeFournisseur> implements ICommandeFournisseurDao {

}
