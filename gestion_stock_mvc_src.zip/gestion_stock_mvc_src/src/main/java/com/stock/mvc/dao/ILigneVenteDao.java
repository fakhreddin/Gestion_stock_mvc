package com.stock.mvc.dao;

import com.stock.mvc.entites.LigneVente;

public interface ILigneVenteDao extends IGenericDao<LigneVente> {

}
