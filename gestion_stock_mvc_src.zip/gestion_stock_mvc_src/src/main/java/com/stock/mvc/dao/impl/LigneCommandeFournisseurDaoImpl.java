package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.ILigneCommandeFournisseurDao;
import com.stock.mvc.entites.LigneCommandeFournisseur;

public class LigneCommandeFournisseurDaoImpl extends GenericDaoImpl<LigneCommandeFournisseur> implements ILigneCommandeFournisseurDao {

}
