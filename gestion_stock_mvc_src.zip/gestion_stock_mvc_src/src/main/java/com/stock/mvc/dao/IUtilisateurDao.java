package com.stock.mvc.dao;

import com.stock.mvc.entites.Utilisateur;

public interface IUtilisateurDao extends IGenericDao<Utilisateur> {

}
