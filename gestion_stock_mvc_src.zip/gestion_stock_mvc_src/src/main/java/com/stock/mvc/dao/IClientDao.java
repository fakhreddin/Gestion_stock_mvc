package com.stock.mvc.dao;

import com.stock.mvc.entites.Client;

public interface IClientDao extends IGenericDao<Client> {

}
