package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.IArticleDao;
import com.stock.mvc.entites.Article;

public class ArticleDaoImpl extends GenericDaoImpl<Article> implements IArticleDao {

}
