package com.stock.mvc.dao;

import com.stock.mvc.entites.CommandeClient;

public interface ICommandeClientDao extends IGenericDao<CommandeClient> {

}
