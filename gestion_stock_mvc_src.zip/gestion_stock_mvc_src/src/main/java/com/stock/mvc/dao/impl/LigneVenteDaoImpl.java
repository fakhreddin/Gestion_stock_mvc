package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.ILigneVenteDao;
import com.stock.mvc.entites.LigneVente;

public class LigneVenteDaoImpl  extends GenericDaoImpl<LigneVente> implements ILigneVenteDao {

}
