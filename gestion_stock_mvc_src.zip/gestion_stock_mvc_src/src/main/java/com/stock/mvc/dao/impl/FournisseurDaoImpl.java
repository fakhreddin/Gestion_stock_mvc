package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.IFournisseurDao;
import com.stock.mvc.entites.Fournisseur;

public class FournisseurDaoImpl extends GenericDaoImpl<Fournisseur> implements IFournisseurDao {

}
