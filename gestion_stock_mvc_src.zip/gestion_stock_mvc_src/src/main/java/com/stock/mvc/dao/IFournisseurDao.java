package com.stock.mvc.dao;

import com.stock.mvc.entites.Fournisseur;

public interface IFournisseurDao extends IGenericDao<Fournisseur> {

}
