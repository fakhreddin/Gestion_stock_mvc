package com.stock.mvc.dao;

import com.stock.mvc.entites.CommandeFournisseur;

public interface ICommandeFournisseurDao extends IGenericDao<CommandeFournisseur> {

}
